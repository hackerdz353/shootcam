globalThis.dataLayer = globalThis.dataLayer || [];
function gtag() {
  globalThis.dataLayer.push(arguments);
}
gtag("js", new Date());

gtag("config", "G-8V8N1Y7TTN");
